package BROWSER1.cgffuhj;

public class Actions {

	public static Object scrollByAmount(int i, int j) {
		// TODO Auto-generated method stub
		return null;
	}

}
