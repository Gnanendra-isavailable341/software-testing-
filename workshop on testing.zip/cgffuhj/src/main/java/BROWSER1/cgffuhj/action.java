package BROWSER1.cgffuhj;

public interface action {

}
